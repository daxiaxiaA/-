package com.example.cryptotask;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.GeneralSecurityException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Base64;

public final class CryptoTaskApp extends JFrame {
    private static final String PACKAGE_MAGIC = "CRYPTO_TASK_V1";

    private final JComboBox<String> inputModeBox = new JComboBox<>(new String[]{"字符串", "文件"});
    private final JComboBox<String> symmetricBox = new JComboBox<>(new String[]{"AES", "DES"});
    private final JComboBox<String> hashBox = new JComboBox<>(new String[]{"SHA-256", "SHA-1", "MD5"});
    private final JComboBox<String> rsaSizeBox = new JComboBox<>(new String[]{"2048", "1024", "512"});
    private final JTextField seedField = new JTextField();
    private final JTextField fileField = new JTextField();
    private final JTextArea inputArea = new JTextArea(8, 45);
    private final JTextArea keyArea = new JTextArea(9, 45);
    private final JTextArea logArea = new JTextArea(14, 45);
    private final JTextArea outputArea = new JTextArea(8, 45);
    private final JCheckBox autoGenerateKeyBox = new JCheckBox("每次执行前按当前算法/种子生成对称密钥", true);

    private final SecureRandom secureRandom = new SecureRandom();
    private KeyPair senderKeyPair;
    private KeyPair receiverKeyPair;
    private SecretKey symmetricKey;
    private String symmetricKeyAlgorithm = "AES";
    private File selectedFile;
    private CryptoPackage lastPackage;
    private byte[] lastDecrypted;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) {
                // Default Swing look and feel is acceptable if the platform one is unavailable.
            }
            new CryptoTaskApp().setVisible(true);
        });
    }

    private CryptoTaskApp() {
        super("加密与数字签名综合实验");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        buildUi();
        initializeDefaults();
        pack();
        setLocationRelativeTo(null);
    }

    private void buildUi() {
        JPanel root = new JPanel(new BorderLayout(10, 10));
        root.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        setContentPane(root);

        JLabel title = new JLabel("A 端签名并加密，B 端解密并验签");
        title.setBorder(BorderFactory.createEmptyBorder(0, 0, 6, 0));
        root.add(title, BorderLayout.NORTH);

        JPanel left = new JPanel(new BorderLayout(8, 8));
        left.add(buildOptionsPanel(), BorderLayout.NORTH);
        left.add(buildInputPanel(), BorderLayout.CENTER);
        left.add(buildButtonPanel(), BorderLayout.SOUTH);

        JPanel right = new JPanel(new BorderLayout(8, 8));
        keyArea.setEditable(false);
        keyArea.setLineWrap(true);
        keyArea.setWrapStyleWord(true);
        logArea.setEditable(false);
        outputArea.setEditable(false);
        outputArea.setLineWrap(true);
        outputArea.setWrapStyleWord(true);

        JSplitPane rightSplit = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
                boxedScroll("密钥信息", keyArea), boxedScroll("过程日志", logArea));
        rightSplit.setResizeWeight(0.38);
        right.add(rightSplit, BorderLayout.CENTER);
        right.add(boxedScroll("B 端解密结果", outputArea), BorderLayout.SOUTH);

        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, left, right);
        split.setResizeWeight(0.45);
        root.add(split, BorderLayout.CENTER);
        setMinimumSize(new Dimension(1120, 720));
    }

    private JPanel buildOptionsPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createTitledBorder("参数选择"));
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(4, 4, 4, 4);
        c.fill = GridBagConstraints.HORIZONTAL;

        addRow(panel, c, 0, "输入类型", inputModeBox);
        addRow(panel, c, 1, "对称算法", symmetricBox);
        addRow(panel, c, 2, "Hash 算法", hashBox);
        addRow(panel, c, 3, "RSA 密钥长度", rsaSizeBox);
        addRow(panel, c, 4, "对称密钥种子", seedField);

        c.gridx = 1;
        c.gridy = 5;
        c.weightx = 1;
        panel.add(autoGenerateKeyBox, c);

        return panel;
    }

    private void addRow(JPanel panel, GridBagConstraints c, int row, String label, java.awt.Component field) {
        c.gridx = 0;
        c.gridy = row;
        c.weightx = 0;
        panel.add(new JLabel(label), c);
        c.gridx = 1;
        c.weightx = 1;
        panel.add(field, c);
    }

    private JPanel buildInputPanel() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setBorder(BorderFactory.createTitledBorder("明文输入"));
        inputArea.setText("这是一段待签名并加密的测试明文。");
        inputArea.setLineWrap(true);
        inputArea.setWrapStyleWord(true);

        JPanel filePanel = new JPanel(new BorderLayout(6, 0));
        fileField.setEditable(false);
        JButton chooseFileButton = new JButton("选择文件");
        chooseFileButton.addActionListener(e -> chooseInputFile());
        filePanel.add(fileField, BorderLayout.CENTER);
        filePanel.add(chooseFileButton, BorderLayout.EAST);

        panel.add(filePanel, BorderLayout.NORTH);
        panel.add(new JScrollPane(inputArea), BorderLayout.CENTER);
        return panel;
    }

    private JPanel buildButtonPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton rsaButton = new JButton("生成 RSA 密钥对");
        JButton symmetricButton = new JButton("生成对称密钥");
        JButton runButton = new JButton("执行完整流程");
        JButton savePackageButton = new JButton("保存密文包");
        JButton openPackageButton = new JButton("打开密文包并验签");
        JButton savePlainButton = new JButton("保存解密结果");

        rsaButton.addActionListener(e -> generateRsaPairs());
        symmetricButton.addActionListener(e -> generateSymmetricKey());
        runButton.addActionListener(e -> runFullProcess());
        savePackageButton.addActionListener(e -> saveLastPackage());
        openPackageButton.addActionListener(e -> openPackageAndVerify());
        savePlainButton.addActionListener(e -> saveLastDecrypted());

        panel.add(rsaButton);
        panel.add(symmetricButton);
        panel.add(runButton);
        panel.add(savePackageButton);
        panel.add(openPackageButton);
        panel.add(savePlainButton);
        return panel;
    }

    private JScrollPane boxedScroll(String title, JTextArea area) {
        JScrollPane scroll = new JScrollPane(area);
        scroll.setBorder(BorderFactory.createTitledBorder(title));
        return scroll;
    }

    private void initializeDefaults() {
        generateRsaPairs();
        generateSymmetricKey();
    }

    private void chooseInputFile() {
        JFileChooser chooser = new JFileChooser();
        if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            selectedFile = chooser.getSelectedFile();
            fileField.setText(selectedFile.getAbsolutePath());
            inputModeBox.setSelectedItem("文件");
        }
    }

    private void generateRsaPairs() {
        try {
            int keySize = Integer.parseInt((String) rsaSizeBox.getSelectedItem());
            if (keySize < 200) {
                throw new IllegalArgumentException("RSA 密钥长度不得小于 200 位。");
            }
            KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");
            generator.initialize(keySize, secureRandom);
            senderKeyPair = generator.generateKeyPair();
            receiverKeyPair = generator.generateKeyPair();
            appendLog("已生成 A/B 两组 RSA 密钥对，长度 " + keySize + " 位。");
            refreshKeyArea();
        } catch (Exception ex) {
            showError("生成 RSA 密钥对失败", ex);
        }
    }

    private void generateSymmetricKey() {
        try {
            String algorithm = (String) symmetricBox.getSelectedItem();
            symmetricKeyAlgorithm = algorithm;
            String seed = seedField.getText().trim();
            byte[] keyBytes;
            if (seed.isEmpty()) {
                KeyGenerator generator = KeyGenerator.getInstance(algorithm);
                if ("AES".equals(algorithm)) {
                    generator.init(128, secureRandom);
                } else {
                    generator.init(56, secureRandom);
                }
                symmetricKey = generator.generateKey();
            } else {
                keyBytes = deriveSymmetricKeyBytes(algorithm, seed);
                symmetricKey = new SecretKeySpec(keyBytes, algorithm);
            }
            appendLog("已生成 " + algorithm + " 对称密钥" + (seed.isEmpty() ? "（随机）" : "（由种子派生）") + "。");
            refreshKeyArea();
        } catch (Exception ex) {
            showError("生成对称密钥失败", ex);
        }
    }

    private byte[] deriveSymmetricKeyBytes(String algorithm, String seed) throws GeneralSecurityException {
        byte[] digest = MessageDigest.getInstance("SHA-256").digest(seed.getBytes(StandardCharsets.UTF_8));
        return Arrays.copyOf(digest, "AES".equals(algorithm) ? 16 : 8);
    }

    private void runFullProcess() {
        try {
            ensureKeysReady();
            if (autoGenerateKeyBox.isSelected() || !symmetricKeyAlgorithm.equals(symmetricBox.getSelectedItem())) {
                generateSymmetricKey();
            }
            byte[] plain = readPlainInput();
            String hashAlgorithm = (String) hashBox.getSelectedItem();
            String symmetricAlgorithm = (String) symmetricBox.getSelectedItem();

            byte[] hash = digest(hashAlgorithm, plain);
            byte[] signature = rsaPrivateEncrypt(hash, senderKeyPair.getPrivate());
            byte[] combined = combinePlainAndSignature(plain, signature);
            SymmetricCipherResult encryptedPayload = encryptSymmetric(symmetricAlgorithm, symmetricKey, combined);
            byte[] encryptedKey = rsaPublicEncrypt(symmetricKey.getEncoded(), receiverKeyPair.getPublic());
            lastPackage = new CryptoPackage(symmetricAlgorithm, hashAlgorithm, encryptedPayload.iv,
                    encryptedKey, encryptedPayload.cipherText);

            VerificationResult result = decryptAndVerify(lastPackage);
            lastDecrypted = result.plainText;
            outputArea.setText(formatOutput(result.plainText));
            appendLog("");
            appendLog("A: 计算 H(M) = " + toHex(hash));
            appendLog("A: 使用 RK_A 对 H(M) 加密得到数字签名，长度 " + signature.length + " 字节。");
            appendLog("A: 组合 M || 签名，使用 " + symmetricAlgorithm + " 和 K 加密，密文长度 "
                    + encryptedPayload.cipherText.length + " 字节。");
            appendLog("A: 使用 UK_B 加密 K，密钥密文长度 " + encryptedKey.length + " 字节。");
            appendLog("B: 使用 RK_B 解出 K，再解出 M || 签名。");
            appendLog("B: 使用 UK_A 解出签名中的 Hash，并与重新计算的 " + hashAlgorithm + " 比较。");
            appendLog(result.verified ? "验签结果：通过。" : "验签结果：失败。");
        } catch (Exception ex) {
            showError("执行完整流程失败", ex);
        }
    }

    private void ensureKeysReady() {
        if (senderKeyPair == null || receiverKeyPair == null) {
            generateRsaPairs();
        }
        if (symmetricKey == null) {
            generateSymmetricKey();
        }
    }

    private byte[] readPlainInput() throws IOException {
        if ("文件".equals(inputModeBox.getSelectedItem())) {
            if (selectedFile == null) {
                throw new IllegalStateException("请先选择要加密和签名的文件。");
            }
            return Files.readAllBytes(selectedFile.toPath());
        }
        return inputArea.getText().getBytes(StandardCharsets.UTF_8);
    }

    private String formatOutput(byte[] bytes) {
        if ("文件".equals(inputModeBox.getSelectedItem())) {
            String name = selectedFile == null ? "未知文件" : selectedFile.getName();
            return "已解密文件内容：" + name + "\n字节数：" + bytes.length
                    + "\n可点击“保存解密结果”导出。";
        }
        return new String(bytes, StandardCharsets.UTF_8);
    }

    private byte[] digest(String algorithm, byte[] data) throws GeneralSecurityException {
        return MessageDigest.getInstance(algorithm).digest(data);
    }

    private byte[] rsaPrivateEncrypt(byte[] data, PrivateKey key) throws GeneralSecurityException {
        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(Cipher.ENCRYPT_MODE, key);
        return cipher.doFinal(data);
    }

    private byte[] rsaPublicDecrypt(byte[] data, PublicKey key) throws GeneralSecurityException {
        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(Cipher.DECRYPT_MODE, key);
        return cipher.doFinal(data);
    }

    private byte[] rsaPublicEncrypt(byte[] data, PublicKey key) throws GeneralSecurityException {
        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(Cipher.ENCRYPT_MODE, key);
        return cipher.doFinal(data);
    }

    private byte[] rsaPrivateDecrypt(byte[] data, PrivateKey key) throws GeneralSecurityException {
        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(Cipher.DECRYPT_MODE, key);
        return cipher.doFinal(data);
    }

    private byte[] combinePlainAndSignature(byte[] plain, byte[] signature) throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (DataOutputStream out = new DataOutputStream(bytes)) {
            out.writeInt(plain.length);
            out.write(plain);
            out.writeInt(signature.length);
            out.write(signature);
        }
        return bytes.toByteArray();
    }

    private PlainAndSignature splitPlainAndSignature(byte[] data) throws IOException {
        try (DataInputStream in = new DataInputStream(new ByteArrayInputStream(data))) {
            int plainLength = in.readInt();
            if (plainLength < 0 || plainLength > data.length) {
                throw new IOException("密文包中的明文长度非法。");
            }
            byte[] plain = in.readNBytes(plainLength);
            int signatureLength = in.readInt();
            if (signatureLength <= 0 || signatureLength > data.length) {
                throw new IOException("密文包中的签名长度非法。");
            }
            byte[] signature = in.readNBytes(signatureLength);
            return new PlainAndSignature(plain, signature);
        }
    }

    private SymmetricCipherResult encryptSymmetric(String algorithm, SecretKey key, byte[] plain)
            throws GeneralSecurityException {
        Cipher cipher = Cipher.getInstance(algorithm + "/CBC/PKCS5Padding");
        byte[] iv = new byte[cipher.getBlockSize()];
        secureRandom.nextBytes(iv);
        cipher.init(Cipher.ENCRYPT_MODE, key, new IvParameterSpec(iv));
        return new SymmetricCipherResult(iv, cipher.doFinal(plain));
    }

    private byte[] decryptSymmetric(String algorithm, SecretKey key, byte[] iv, byte[] cipherText)
            throws GeneralSecurityException {
        Cipher cipher = Cipher.getInstance(algorithm + "/CBC/PKCS5Padding");
        cipher.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(iv));
        return cipher.doFinal(cipherText);
    }

    private VerificationResult decryptAndVerify(CryptoPackage cryptoPackage)
            throws GeneralSecurityException, IOException {
        byte[] keyBytes = rsaPrivateDecrypt(cryptoPackage.encryptedKey, receiverKeyPair.getPrivate());
        SecretKey receivedKey = new SecretKeySpec(keyBytes, cryptoPackage.symmetricAlgorithm);
        byte[] combined = decryptSymmetric(cryptoPackage.symmetricAlgorithm, receivedKey,
                cryptoPackage.iv, cryptoPackage.encryptedPayload);
        PlainAndSignature plainAndSignature = splitPlainAndSignature(combined);
        byte[] expectedHash = digest(cryptoPackage.hashAlgorithm, plainAndSignature.plainText);
        byte[] signatureHash = rsaPublicDecrypt(plainAndSignature.signature, senderKeyPair.getPublic());
        boolean verified = MessageDigest.isEqual(expectedHash, signatureHash);
        return new VerificationResult(plainAndSignature.plainText, verified);
    }

    private void saveLastPackage() {
        if (lastPackage == null) {
            JOptionPane.showMessageDialog(this, "请先执行完整流程生成密文包。");
            return;
        }
        JFileChooser chooser = new JFileChooser();
        chooser.setSelectedFile(new File("message.crypto"));
        chooser.setFileFilter(new FileNameExtensionFilter("Crypto package (*.crypto)", "crypto"));
        if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            try {
                Files.write(chooser.getSelectedFile().toPath(), lastPackage.toBytes());
                appendLog("已保存密文包：" + chooser.getSelectedFile().getAbsolutePath());
            } catch (Exception ex) {
                showError("保存密文包失败", ex);
            }
        }
    }

    private void openPackageAndVerify() {
        JFileChooser chooser = new JFileChooser();
        chooser.setFileFilter(new FileNameExtensionFilter("Crypto package (*.crypto)", "crypto"));
        if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            try {
                CryptoPackage cryptoPackage = CryptoPackage.fromBytes(Files.readAllBytes(chooser.getSelectedFile().toPath()));
                VerificationResult result = decryptAndVerify(cryptoPackage);
                lastPackage = cryptoPackage;
                lastDecrypted = result.plainText;
                outputArea.setText(formatOutput(result.plainText));
                appendLog("已打开密文包：" + chooser.getSelectedFile().getAbsolutePath());
                appendLog(result.verified ? "验签结果：通过。" : "验签结果：失败。");
            } catch (Exception ex) {
                showError("打开密文包或验签失败", ex);
            }
        }
    }

    private void saveLastDecrypted() {
        if (lastDecrypted == null) {
            JOptionPane.showMessageDialog(this, "暂无解密结果。");
            return;
        }
        JFileChooser chooser = new JFileChooser();
        chooser.setSelectedFile(new File(selectedFile == null ? "decrypted.txt" : "decrypted-" + selectedFile.getName()));
        if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            try {
                Files.write(chooser.getSelectedFile().toPath(), lastDecrypted);
                appendLog("已保存解密结果：" + chooser.getSelectedFile().getAbsolutePath());
            } catch (Exception ex) {
                showError("保存解密结果失败", ex);
            }
        }
    }

    private void refreshKeyArea() {
        StringBuilder builder = new StringBuilder();
        if (symmetricKey != null) {
            builder.append("对称算法: ").append(symmetricKeyAlgorithm).append('\n');
            builder.append("K(Base64): ").append(Base64.getEncoder().encodeToString(symmetricKey.getEncoded())).append("\n\n");
        }
        if (senderKeyPair != null) {
            builder.append("A 私钥 RK_A(Base64): ").append(shortBase64(senderKeyPair.getPrivate().getEncoded())).append('\n');
            builder.append("A 公钥 UK_A(Base64): ").append(shortBase64(senderKeyPair.getPublic().getEncoded())).append("\n\n");
        }
        if (receiverKeyPair != null) {
            builder.append("B 私钥 RK_B(Base64): ").append(shortBase64(receiverKeyPair.getPrivate().getEncoded())).append('\n');
            builder.append("B 公钥 UK_B(Base64): ").append(shortBase64(receiverKeyPair.getPublic().getEncoded())).append('\n');
        }
        keyArea.setText(builder.toString());
    }

    private String shortBase64(byte[] data) {
        String encoded = Base64.getEncoder().encodeToString(data);
        return encoded.length() <= 96 ? encoded : encoded.substring(0, 96) + "...";
    }

    private String toHex(byte[] data) {
        StringBuilder builder = new StringBuilder(data.length * 2);
        for (byte b : data) {
            builder.append(String.format("%02x", b));
        }
        return builder.toString();
    }

    private void appendLog(String message) {
        logArea.append(message + "\n");
        logArea.setCaretPosition(logArea.getDocument().getLength());
    }

    private void showError(String title, Exception ex) {
        appendLog(title + "：" + ex.getMessage());
        JOptionPane.showMessageDialog(this, ex.getMessage(), title, JOptionPane.ERROR_MESSAGE);
    }

    private record SymmetricCipherResult(byte[] iv, byte[] cipherText) {
    }

    private record PlainAndSignature(byte[] plainText, byte[] signature) {
    }

    private record VerificationResult(byte[] plainText, boolean verified) {
    }

    private record CryptoPackage(String symmetricAlgorithm, String hashAlgorithm, byte[] iv,
                                 byte[] encryptedKey, byte[] encryptedPayload) {
        private byte[] toBytes() throws IOException {
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            try (DataOutputStream out = new DataOutputStream(bytes)) {
                out.writeUTF(PACKAGE_MAGIC);
                out.writeUTF(symmetricAlgorithm);
                out.writeUTF(hashAlgorithm);
                writeBytes(out, iv);
                writeBytes(out, encryptedKey);
                writeBytes(out, encryptedPayload);
            }
            return bytes.toByteArray();
        }

        private static CryptoPackage fromBytes(byte[] data) throws IOException {
            try (DataInputStream in = new DataInputStream(new ByteArrayInputStream(data))) {
                String magic = in.readUTF();
                if (!PACKAGE_MAGIC.equals(magic)) {
                    throw new IOException("不是本程序生成的密文包。");
                }
                String symmetricAlgorithm = in.readUTF();
                String hashAlgorithm = in.readUTF();
                return new CryptoPackage(symmetricAlgorithm, hashAlgorithm,
                        readBytes(in), readBytes(in), readBytes(in));
            }
        }

        private static void writeBytes(DataOutputStream out, byte[] data) throws IOException {
            out.writeInt(data.length);
            out.write(data);
        }

        private static byte[] readBytes(DataInputStream in) throws IOException {
            int length = in.readInt();
            if (length < 0 || length > 100 * 1024 * 1024) {
                throw new IOException("密文包字段长度非法。");
            }
            return in.readNBytes(length);
        }
    }
}
